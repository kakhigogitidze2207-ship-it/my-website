import { i as __toESM } from "../_runtime.mjs";
import { R as require_react, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Moon, c as Clock, i as Phone, o as Menu, r as Sun, s as MapPin, t as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BibBd-aA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var copy = {
	en: {
		navAbout: "About",
		navMenu: "Menu",
		navGallery: "Gallery",
		navVisit: "Visit",
		navReserve: "Reserve",
		heroEyebrow: "The first specialty coffee shop in Batumi",
		heroTitle: "PINCH",
		heroSubtitle: "Crafted coffee. Honest ingredients. A quiet moment in the heart of the city.",
		heroMenu: "Explore menu",
		heroVisit: "Find us",
		aboutEyebrow: "Our story",
		aboutTitle: "Where specialty coffee began in Batumi",
		aboutLead: "PINCH was the first specialty coffee shop in town — a small, intentional space dedicated to exceptional beans, precise brewing, and the simple pleasure of a perfect cup.",
		aboutBody: "We source carefully and serve with care. From classic espresso to a delicate V60, every drink is dialed in daily. Alongside the coffee: house-made pastries and sandwiches made from scratch.",
		statRating: "Google rating",
		statReviews: "Reviews",
		statFirst: "Specialty in town",
		quoteLabel: "Since day one",
		quoteBody: "Consistent quality, honest craft, and a warm welcome — every single day.",
		menuEyebrow: "The menu",
		menuTitle: "Coffee & more",
		menuDesc: "Specialty espresso, filter, house pastries, and freshly made sandwiches.",
		tabCoffee: "Coffee",
		tabPastries: "Pastries",
		tabSandwiches: "Sandwiches",
		fromGel: "from ₾",
		houseMade: "House-made",
		daily: "Daily",
		signature: "Signature",
		espresso: "Espresso",
		espressoDesc: "Single origin or house blend. Clean, sweet, precisely extracted.",
		cappuccino: "Cappuccino",
		cappuccinoDesc: "Silky microfoam, balanced espresso. A Batumi favourite.",
		v60: "V60 pour-over",
		v60Desc: "Hand-brewed filter coffee. Bright, transparent, aromatic.",
		irish: "Irish coffee",
		irishDesc: "Classic recipe with quality whiskey, brown sugar, and cream.",
		latte: "Flat white / latte",
		latteDesc: "Velvety milk, rich espresso. Smooth and comforting.",
		filter: "Filter / batch brew",
		filterDesc: "Daily filter coffee — approachable and full of character.",
		cinnamon: "Cinnamon roll",
		cinnamonDesc: "Warm, fragrant, and baked fresh. Perfect with morning coffee.",
		seasonal: "Seasonal pastries",
		seasonalDesc: "A rotating selection of sweets made in-house every day.",
		croissant: "Croissants",
		croissantDesc: "Buttery, flaky, ready to pair with espresso.",
		tuna: "Tuna & egg",
		tunaDesc: "Soft ciabatta, creamy-spicy sauce, tuna & egg, pickled red onion, lettuce.",
		chicken: "Chicken & pickles",
		chickenDesc: "Ciabatta, signature sauce, baked chicken breast, pickled cucumber, lettuce.",
		tomato: "Sun-dried tomato",
		tomatoDesc: "Ciabatta, signature sauce, egg, sun-dried tomatoes, lettuce.",
		sandwichNote: "All sandwiches made in-house — natural, fresh, and ready for dine-in or takeaway.",
		galleryEyebrow: "The space",
		galleryTitle: "A quieter cup",
		galleryDesc: "Bar, brew, pastry, and the street outside.",
		expTitle: "How we work",
		exp1t: "Specialty focus",
		exp1d: "Origin, process, and precise extraction — coffee treated as craft.",
		exp2t: "House-made",
		exp2d: "Pastries and sandwiches prepared daily from scratch.",
		exp3t: "Takeaway ready",
		exp3d: "Stay at the bar or take a well-made cup onto the avenue.",
		exp4t: "Beans to go",
		exp4d: "Take home freshly roasted beans and grind them yourself.",
		visitEyebrow: "Find us",
		visitTitle: "Visit PINCH",
		address: "Address",
		hours: "Hours",
		phone: "Phone",
		services: "Services",
		hoursWeek: "Mon–Fri 08:30 – 21:00",
		hoursWeekend: "Sat–Sun 09:00 – 21:00",
		dineTake: "Dine-in · Takeaway",
		openMaps: "Open in Maps",
		nearMuseum: "Near the Museum of Fine Arts · Central Batumi",
		reserveEyebrow: "A table",
		reserveTitle: "Reserve a visit",
		reserveDesc: "Small room, limited tables. Leave a request and we’ll confirm by phone.",
		name: "Name",
		guests: "Guests",
		date: "Date",
		time: "Time",
		notes: "Notes",
		notesPh: "Window table, allergies, celebration…",
		send: "Send request",
		sent: "Request saved",
		sentBody: "We’ll call you to confirm. You can also reach us directly.",
		required: "Please fill name, phone, date and time.",
		contactTitle: "Come for the coffee.\nStay for the moment.",
		contactBody: "Daily specials, new sandwiches, and the bar — on Instagram.",
		instagram: "Instagram",
		callUs: "Call us",
		maps: "Google Maps",
		footerTag: "Specialty coffee in the heart of Batumi.",
		lang: "ქარ",
		themeDay: "Day",
		themeNight: "Night",
		close: "Close"
	},
	ka: {
		navAbout: "ჩვენს შესახებ",
		navMenu: "მენიუ",
		navGallery: "გალერეა",
		navVisit: "მისამართი",
		navReserve: "ჯავშანი",
		heroEyebrow: "ბათუმის პირველი სპეციალთი ყავის სახლი",
		heroTitle: "PINCH",
		heroSubtitle: "ხელოსნური ყავა. გულწრფელი ინგრედიენტები. მშვიდი წუთი ქალაქის გულში.",
		heroMenu: "მენიუ",
		heroVisit: "მოგვაკითხეთ",
		aboutEyebrow: "ისტორია",
		aboutTitle: "სადაც სპეციალთი ყავა დაიწყო ბათუმში",
		aboutLead: "PINCH იყო ქალაქის პირველი სპეციალთი ყავის სახლი — პატარა, გააზრებული სივრცე გამორჩეული მარცვლის, ზუსტი მომზადებისა და სრულყოფილი ფინჯნისთვის.",
		aboutBody: "ყოველდღე ვაკალიბრებთ ესპრესოსა და V60-ს. ყავასთან ერთად — საკუთარი ცომეული და სენდვიჩები, დილიდან.",
		statRating: "Google შეფასება",
		statReviews: "შეფასება",
		statFirst: "პირველი სპეციალთი",
		quoteLabel: "პირველი დღიდან",
		quoteBody: "სტაბილური ხარისხი, გულწრფელი ხელობა და თბილი მიღება — ყოველდღე.",
		menuEyebrow: "მენიუ",
		menuTitle: "ყავა და სხვა",
		menuDesc: "სპეციალთი ესპრესო, ფილტრი, საკუთარი ცომეული და სენდვიჩები.",
		tabCoffee: "ყავა",
		tabPastries: "ცომეული",
		tabSandwiches: "სენდვიჩები",
		fromGel: "₾-დან",
		houseMade: "საკუთარი",
		daily: "ყოველდღე",
		signature: "საფირმო",
		espresso: "ესპრესო",
		espressoDesc: "სინგლ ორიჯინი ან ჰაუს ბლენდი. სუფთა, ტკბილი, ზუსტი ექსტრაქცია.",
		cappuccino: "კაპუჩინო",
		cappuccinoDesc: "აბრეშუმისებრი ქაფი, დაბალანსებული ესპრესო. ბათუმის რჩეული.",
		v60: "V60",
		v60Desc: "ხელით დაბრუნებული ფილტრი. ნათელი, გამჭვირვალე, არომატული.",
		irish: "აირლანდიური ყავა",
		irishDesc: "კლასიკური რეცეპტი ვისკით, შავი შაქრით და ნაღებით.",
		latte: "ფლეტ უაით / ლატე",
		latteDesc: "ხავერდოვანი რძე, მდიდარი ესპრესო.",
		filter: "ფილტრი",
		filterDesc: "დღის ფილტრი — მარტივი და ხასიათიანი.",
		cinnamon: "დარიჩინის როლი",
		cinnamonDesc: "თბილი, სურნელოვანი, ახალი. დილის ყავასთან.",
		seasonal: "სეზონური ცომეული",
		seasonalDesc: "ყოველდღე ახალი, საკუთარი სამზარეულოდან.",
		croissant: "კრუასანი",
		croissantDesc: "კარაქიანი, ფენოვანი — ესპრესოსთან.",
		tuna: "თინუსი და კვერცხი",
		tunaDesc: "ჩაბატა, კრემოვან-ცხარე სოუსი, თინუსი, კვერცხი, წითელი ხახვი, სალათა.",
		chicken: "ქათამი და მწნილი",
		chickenDesc: "ჩაბატა, საფირმო სოუსი, გამომცხვარი ქათამი, კიტრი, სალათა.",
		tomato: "მზეზე გამშრალი პომიდორი",
		tomatoDesc: "ჩაბატა, საფირმო სოუსი, კვერცხი, მზეზე გამშრალი პომიდორი, სალათა.",
		sandwichNote: "ყველა სენდვიჩი საკუთარია — ადგილზე ან წასაღებად.",
		galleryEyebrow: "სივრცე",
		galleryTitle: "უფრო მშვიდი ფინჯანი",
		galleryDesc: "ბარი, დუღილი, ცომეული და ქუჩა გარეთ.",
		expTitle: "როგორ ვმუშაობთ",
		exp1t: "სპეციალთი",
		exp1d: "წარმომავლობა, პროცესი და ზუსტი ექსტრაქცია.",
		exp2t: "საკუთარი სამზარეულო",
		exp2d: "ცომეული და სენდვიჩები ყოველდღე, ნულიდან.",
		exp3t: "წასაღები",
		exp3d: "დარჩით ბართან ან წაიღეთ ფინჯანი გამზირზე.",
		exp4t: "მარცვალი სახლში",
		exp4d: "ახლად შემწვარი მარცვალი — დაფქვით თქვენით.",
		visitEyebrow: "მისამართი",
		visitTitle: "მოგვაკითხეთ",
		address: "მისამართი",
		hours: "საათები",
		phone: "ტელეფონი",
		services: "სერვისი",
		hoursWeek: "ორშ–პარ 08:30 – 21:00",
		hoursWeekend: "შაბ–კვი 09:00 – 21:00",
		dineTake: "ადგილზე · წასაღები",
		openMaps: "რუკაზე",
		nearMuseum: "სახვითი ხელოვნების მუზეუმთან · ცენტრი",
		reserveEyebrow: "მაგიდა",
		reserveTitle: "დაჯავშნეთ ვიზიტი",
		reserveDesc: "პატარა დარბაზი, შეზღუდული მაგიდები. დაგვიტოვეთ მოთხოვნა — დაგირეკავთ.",
		name: "სახელი",
		guests: "სტუმრები",
		date: "თარიღი",
		time: "დრო",
		notes: "შენიშვნა",
		notesPh: "ფანჯარასთან, ალერგია, დღესასწაული…",
		send: "გაგზავნა",
		sent: "მოთხოვნა შენახულია",
		sentBody: "დასადასტურებლად დაგირეკავთ. შეგიძლიათ პირდაპირაც დაგვიკავშირდეთ.",
		required: "შეავსეთ სახელი, ტელეფონი, თარიღი და დრო.",
		contactTitle: "მოდით ყავისთვის.\nდარჩით მომენტისთვის.",
		contactBody: "დღის სპეციალი და ახალი სენდვიჩები — ინსტაგრამზე.",
		instagram: "ინსტაგრამი",
		callUs: "დარეკვა",
		maps: "რუკა",
		footerTag: "სპეციალთი ყავა ბათუმის გულში.",
		lang: "EN",
		themeDay: "დღე",
		themeNight: "ღამე",
		close: "დახურვა"
	}
};
function t(lang, key) {
	return copy[lang][key];
}
function persist() {
	if (typeof window === "undefined") return;
	const { lang, theme } = usePrefs.getState();
	localStorage.setItem("pinch-prefs", JSON.stringify({
		lang,
		theme
	}));
	document.documentElement.lang = lang;
	document.documentElement.dataset.theme = theme;
}
var usePrefs = create((set) => ({
	lang: "en",
	theme: "night",
	setLang: (lang) => {
		set({ lang });
		persist();
	},
	setTheme: (theme) => {
		set({ theme });
		persist();
	},
	hydrate: () => {
		if (typeof window === "undefined") return;
		try {
			const raw = localStorage.getItem("pinch-prefs");
			if (raw) {
				const parsed = JSON.parse(raw);
				set({
					lang: parsed.lang === "ka" ? "ka" : "en",
					theme: parsed.theme === "day" ? "day" : "night"
				});
			}
		} catch {}
		persist();
	}
}));
var KEY = "pinch-reservations";
function listReservations() {
	if (typeof window === "undefined") return [];
	try {
		const raw = localStorage.getItem(KEY);
		return raw ? JSON.parse(raw) : [];
	} catch {
		return [];
	}
}
function saveReservation(input) {
	const item = {
		...input,
		id: crypto.randomUUID(),
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	const next = [item, ...listReservations()].slice(0, 20);
	localStorage.setItem(KEY, JSON.stringify(next));
	return item;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var MAPS = "https://www.google.com/maps/search/?api=1&query=60+Memed+Abashidze+Ave,+Batumi+6004";
var IG = "https://www.instagram.com/pinch_coffee_ge/";
var TEL = "+995595502265";
var TEL_DISPLAY = "+995 595 50 22 65";
var GALLERY = [
	{
		src: "/images/interior.jpg",
		key: "interior",
		w: "wide"
	},
	{
		src: "/images/cappuccino.jpg",
		key: "cappuccino",
		w: "sq"
	},
	{
		src: "/images/v60.jpg",
		key: "v60",
		w: "sq"
	},
	{
		src: "/images/cinnamon.jpg",
		key: "cinnamon",
		w: "sq"
	},
	{
		src: "/images/sandwich.jpg",
		key: "sandwich",
		w: "sq"
	},
	{
		src: "/images/beans.jpg",
		key: "beans",
		w: "sq"
	},
	{
		src: "/images/storefront.jpg",
		key: "storefront",
		w: "wide"
	}
];
function Site() {
	const { lang, theme, setLang, setTheme, hydrate } = usePrefs();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [tab, setTab] = (0, import_react.useState)("coffee");
	const [lightbox, setLightbox] = (0, import_react.useState)(null);
	const [sent, setSent] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		phone: "",
		date: "",
		time: "",
		guests: "2",
		notes: ""
	});
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		const tomorrow = /* @__PURE__ */ new Date();
		tomorrow.setDate(tomorrow.getDate() + 1);
		const date = tomorrow.toISOString().slice(0, 10);
		setForm((f) => ({
			...f,
			date: f.date || date,
			time: f.time || "10:00"
		}));
	}, []);
	const tr = (key) => t(lang, key);
	const coffee = (0, import_react.useMemo)(() => [
		["espresso", "espressoDesc"],
		["cappuccino", "cappuccinoDesc"],
		["v60", "v60Desc"],
		["irish", "irishDesc"],
		["latte", "latteDesc"],
		["filter", "filterDesc"]
	], []);
	const pastries = (0, import_react.useMemo)(() => [
		[
			"cinnamon",
			"cinnamonDesc",
			"houseMade"
		],
		[
			"seasonal",
			"seasonalDesc",
			"daily"
		],
		[
			"croissant",
			"croissantDesc",
			"daily"
		]
	], []);
	const sandwiches = (0, import_react.useMemo)(() => [
		["tuna", "tunaDesc"],
		["chicken", "chickenDesc"],
		["tomato", "tomatoDesc"]
	], []);
	function submit(e) {
		e.preventDefault();
		if (!form.name.trim() || !form.phone.trim() || !form.date || !form.time) {
			toast.error(tr("required"));
			return;
		}
		saveReservation({
			name: form.name.trim(),
			phone: form.phone.trim(),
			date: form.date,
			time: form.time,
			guests: Number(form.guests) || 2,
			notes: form.notes.trim()
		});
		setSent(true);
		toast.success(tr("sent"));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "fixed inset-x-0 top-0 z-40 border-b border-line bg-bg/90 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#top",
							className: "font-display text-xl tracking-[0.18em]",
							children: "PINCH"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "hidden items-center gap-7 text-sm text-muted md:flex",
							children: [[
								"navAbout",
								"navMenu",
								"navGallery",
								"navVisit"
							].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `#${k.replace("nav", "").toLowerCase()}`,
								className: "transition-colors duration-150 hover:text-fg",
								children: tr(k)
							}, k)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#reserve",
								className: "rounded-full border border-line-strong px-4 py-2 text-accent transition-colors duration-150 hover:bg-accent hover:text-accent-fg",
								children: tr("navReserve")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setLang(lang === "en" ? "ka" : "en"),
									className: "min-h-11 min-w-11 rounded-full border border-line px-3 text-xs tracking-wide text-muted hover:text-fg",
									"aria-label": "Language",
									children: tr("lang")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setTheme(theme === "night" ? "day" : "night"),
									className: "flex min-h-11 min-w-11 items-center justify-center rounded-full border border-line text-muted hover:text-fg",
									"aria-label": theme === "night" ? tr("themeDay") : tr("themeNight"),
									children: theme === "night" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "flex min-h-11 min-w-11 items-center justify-center rounded-full border border-line md:hidden",
									onClick: () => setOpen((v) => !v),
									"aria-label": "Menu",
									children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" })
								})
							]
						})
					]
				}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-1 border-t border-line px-4 py-3 md:hidden",
					children: [
						["about", "navAbout"],
						["menu", "navMenu"],
						["gallery", "navGallery"],
						["visit", "navVisit"],
						["reserve", "navReserve"]
					].map(([id, k]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `#${id}`,
						onClick: () => setOpen(false),
						className: "rounded-md px-3 py-3 text-sm",
						children: tr(k)
					}, id))
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "top",
				className: "relative flex min-h-dvh items-end overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/hero.jpg",
						alt: "",
						className: "absolute inset-0 size-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-bg/20" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 mx-auto w-full max-w-6xl px-4 pb-20 pt-32 sm:px-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-4 text-xs font-medium uppercase tracking-[0.22em] text-accent",
								children: tr("heroEyebrow")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-6xl font-medium tracking-[0.08em] sm:text-8xl",
								children: tr("heroTitle")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-md text-base text-muted",
								children: tr("heroSubtitle")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#menu",
									className: "inline-flex min-h-11 items-center rounded-full bg-accent px-6 text-sm font-medium tracking-wide text-accent-fg transition-transform duration-150 hover:-translate-y-px",
									children: tr("heroMenu")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#visit",
									className: "inline-flex min-h-11 items-center rounded-full border border-line-strong px-6 text-sm tracking-wide text-fg transition-colors duration-150 hover:border-accent",
									children: tr("heroVisit")
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "about",
				className: "mx-auto grid max-w-6xl gap-12 px-4 py-24 sm:px-6 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.2em] text-accent",
							children: tr("aboutEyebrow")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-4xl font-medium leading-tight sm:text-5xl",
							children: tr("aboutTitle")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-lg text-fg",
							children: tr("aboutLead")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-muted",
							children: tr("aboutBody")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 grid grid-cols-3 gap-6 border-t border-line pt-8",
							children: [
								["4.6", "statRating"],
								["241+", "statReviews"],
								["1st", "statFirst"]
							].map(([n, k]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-display text-3xl text-accent",
								children: n
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-xs uppercase tracking-wider text-subtle",
								children: tr(k)
							})] }, k))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/interior.jpg",
						alt: "",
						className: "mb-4 aspect-photo w-full rounded-xl object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
						className: "rounded-xl border border-line bg-surface p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.16em] text-accent",
							children: tr("quoteLabel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-xl italic leading-snug",
							children: tr("quoteBody")
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "menu",
				className: "bg-elevated py-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl px-4 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-xl text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium uppercase tracking-[0.2em] text-accent",
									children: tr("menuEyebrow")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-display text-4xl font-medium sm:text-5xl",
									children: tr("menuTitle")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-muted",
									children: tr("menuDesc")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 flex flex-wrap justify-center gap-2",
							children: [
								"coffee",
								"pastries",
								"sandwiches"
							].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setTab(id),
								className: cn("min-h-11 rounded-full px-5 text-sm tracking-wide transition-colors duration-150", tab === id ? "bg-accent text-accent-fg" : "border border-line text-muted hover:text-fg"),
								children: tr(id === "coffee" ? "tabCoffee" : id === "pastries" ? "tabPastries" : "tabSandwiches")
							}, id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
							children: [
								tab === "coffee" ? coffee.map(([title, desc]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "rounded-xl border border-line bg-surface p-6 transition-transform duration-150 hover:-translate-y-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-display text-xl",
											children: tr(title)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-accent",
											children: tr("fromGel")
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm text-muted",
										children: tr(desc)
									})]
								}, title)) : null,
								tab === "pastries" ? pastries.map(([title, desc, tag]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "rounded-xl border border-line bg-surface p-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-display text-xl",
											children: tr(title)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-accent",
											children: tr(tag)
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm text-muted",
										children: tr(desc)
									})]
								}, title)) : null,
								tab === "sandwiches" ? sandwiches.map(([title, desc]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "rounded-xl border border-line bg-surface p-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-display text-xl",
											children: tr(title)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-accent",
											children: tr("signature")
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm text-muted",
										children: tr(desc)
									})]
								}, title)) : null
							]
						}),
						tab === "sandwiches" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-center text-sm italic text-subtle",
							children: tr("sandwichNote")
						}) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "gallery",
				className: "mx-auto max-w-6xl px-4 py-24 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.2em] text-accent",
						children: tr("galleryEyebrow")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl font-medium sm:text-5xl",
						children: tr("galleryTitle")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-lg text-muted",
						children: tr("galleryDesc")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid grid-cols-2 gap-3 md:grid-cols-4",
						children: GALLERY.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setLightbox(item.src),
							className: cn("group overflow-hidden rounded-lg", item.w === "wide" ? "col-span-2" : "", i === 0 ? "md:col-span-2 md:row-span-2" : ""),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: item.src,
								alt: "",
								className: "aspect-square size-full object-cover transition-transform duration-300 group-hover:scale-105"
							})
						}, item.src))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-y border-line bg-elevated py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-6xl gap-10 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-4",
					children: [
						["exp1t", "exp1d"],
						["exp2t", "exp2d"],
						["exp3t", "exp3d"],
						["exp4t", "exp4d"]
					].map(([title, desc]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-xl",
						children: tr(title)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: tr(desc)
					})] }, title))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "visit",
				className: "mx-auto grid max-w-6xl gap-12 px-4 py-24 sm:px-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.2em] text-accent",
						children: tr("visitEyebrow")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl font-medium sm:text-5xl",
						children: tr("visitTitle")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-10 grid gap-8 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs uppercase tracking-wider text-accent",
								children: tr("address")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "mt-2 text-muted",
								children: [
									"60 Memed Abashidze Ave",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Batumi 6004"
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs uppercase tracking-wider text-accent",
								children: tr("hours")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "mt-2 text-muted",
								children: [
									tr("hoursWeek"),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									tr("hoursWeekend")
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs uppercase tracking-wider text-accent",
								children: tr("phone")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "text-muted hover:text-accent",
									href: `tel:${TEL}`,
									children: TEL_DISPLAY
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs uppercase tracking-wider text-accent",
								children: tr("services")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-2 text-muted",
								children: tr("dineTake")
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: MAPS,
						target: "_blank",
						rel: "noreferrer",
						className: "mt-8 inline-flex min-h-11 items-center gap-2 rounded-full bg-accent px-6 text-sm font-medium text-accent-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }), tr("openMaps")]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative overflow-hidden rounded-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/storefront.jpg",
						alt: "",
						className: "size-full min-h-72 object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg to-transparent p-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 text-sm text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4 text-accent" }), tr("nearMuseum")]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "reserve",
				className: "bg-elevated py-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-12 px-4 sm:px-6 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.2em] text-accent",
							children: tr("reserveEyebrow")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-4xl font-medium sm:text-5xl",
							children: tr("reserveTitle")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-muted",
							children: tr("reserveDesc")
						})
					] }), sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line bg-surface p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-2xl",
								children: tr("sent")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-muted",
								children: tr("sentBody")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `tel:${TEL}`,
								className: "mt-6 inline-flex min-h-11 items-center gap-2 text-accent",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), TEL_DISPLAY]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "rounded-xl border border-line bg-surface p-6 sm:p-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-subtle",
										children: tr("name")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: form.name,
										onChange: (e) => setForm({
											...form,
											name: e.target.value
										}),
										className: "mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg outline-none focus:border-accent"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-subtle",
										children: tr("phone")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: form.phone,
										onChange: (e) => setForm({
											...form,
											phone: e.target.value
										}),
										className: "mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg outline-none focus:border-accent"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-subtle",
										children: tr("date")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "date",
										value: form.date,
										onChange: (e) => setForm({
											...form,
											date: e.target.value
										}),
										className: "mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg outline-none focus:border-accent"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-subtle",
										children: tr("time")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "time",
										value: form.time,
										onChange: (e) => setForm({
											...form,
											time: e.target.value
										}),
										className: "mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg outline-none focus:border-accent"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-subtle",
										children: tr("guests")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										value: form.guests,
										onChange: (e) => setForm({
											...form,
											guests: e.target.value
										}),
										className: "mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg outline-none focus:border-accent",
										children: [
											1,
											2,
											3,
											4,
											5,
											6
										].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: n,
											children: n
										}, n))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm sm:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-subtle",
										children: tr("notes")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										value: form.notes,
										placeholder: tr("notesPh"),
										onChange: (e) => setForm({
											...form,
											notes: e.target.value
										}),
										rows: 3,
										className: "mt-1 w-full rounded-md border border-line bg-bg px-3 py-2 text-fg outline-none focus:border-accent"
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "mt-6 inline-flex min-h-11 w-full items-center justify-center rounded-full bg-accent px-6 text-sm font-medium text-accent-fg sm:w-auto",
							children: tr("send")
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-2xl px-4 py-24 text-center sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl font-medium whitespace-pre-line sm:text-5xl",
						children: tr("contactTitle")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-muted",
						children: tr("contactBody")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap justify-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: IG,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex min-h-11 items-center rounded-full border border-line-strong px-5 text-sm text-muted hover:text-fg",
								children: tr("instagram")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:${TEL}`,
								className: "inline-flex min-h-11 items-center rounded-full border border-line-strong px-5 text-sm text-muted hover:text-fg",
								children: tr("callUs")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: MAPS,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex min-h-11 items-center rounded-full border border-line-strong px-5 text-sm text-muted hover:text-fg",
								children: tr("maps")
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-line py-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 px-4 sm:flex-row sm:items-center sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-lg tracking-[0.16em]",
						children: "PINCH"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-subtle",
						children: tr("footerTag")
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-subtle",
						children: "60 Memed Abashidze Ave, Batumi"
					})]
				})
			}),
			lightbox ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-bg/90 p-4",
				onClick: () => setLightbox(null),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute top-4 right-4 flex min-h-11 min-w-11 items-center justify-center rounded-full border border-line",
					"aria-label": tr("close"),
					onClick: () => setLightbox(null),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: lightbox,
					alt: "",
					className: "max-h-[85vh] max-w-full rounded-lg object-contain",
					onClick: (e) => e.stopPropagation()
				})]
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Site, {});
}
//#endregion
export { Home as component };
