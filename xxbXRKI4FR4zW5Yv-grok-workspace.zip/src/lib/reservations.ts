export type Reservation = {
  id: string;
  name: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  notes: string;
  createdAt: string;
};

const KEY = "pinch-reservations";

export function listReservations(): Reservation[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Reservation[]) : [];
  } catch {
    return [];
  }
}

export function saveReservation(input: Omit<Reservation, "id" | "createdAt">): Reservation {
  const item: Reservation = {
    ...input,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
  };
  const next = [item, ...listReservations()].slice(0, 20);
  localStorage.setItem(KEY, JSON.stringify(next));
  return item;
}
