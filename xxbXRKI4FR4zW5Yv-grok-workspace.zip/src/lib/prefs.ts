import { create } from "zustand";

export type Lang = "en" | "ka";
export type Theme = "night" | "day";

type Prefs = {
  lang: Lang;
  theme: Theme;
  setLang: (lang: Lang) => void;
  setTheme: (theme: Theme) => void;
  hydrate: () => void;
};

function persist() {
  if (typeof window === "undefined") return;
  const { lang, theme } = usePrefs.getState();
  localStorage.setItem("pinch-prefs", JSON.stringify({ lang, theme }));
  document.documentElement.lang = lang;
  document.documentElement.dataset.theme = theme;
}

export const usePrefs = create<Prefs>((set) => ({
  lang: "en",
  theme: "night",
  setLang: (lang) => {
    set({ lang });
    persist();
  },
  setTheme: (theme) => {
    set({ theme });
    persist();
  },
  hydrate: () => {
    if (typeof window === "undefined") return;
    try {
      const raw = localStorage.getItem("pinch-prefs");
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<Prefs>;
        set({
          lang: parsed.lang === "ka" ? "ka" : "en",
          theme: parsed.theme === "day" ? "day" : "night",
        });
      }
    } catch {
      /* ignore */
    }
    persist();
  },
}));
