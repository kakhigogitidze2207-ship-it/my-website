import { useEffect, useMemo, useState } from "react";
import {
  Clock,
  MapPin,
  Menu,
  Moon,
  Phone,
  Sun,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { t, type CopyKey } from "@/lib/i18n";
import { usePrefs } from "@/lib/prefs";
import { saveReservation } from "@/lib/reservations";
import { cn } from "@/lib/utils";

const MAPS =
  "https://www.google.com/maps/search/?api=1&query=60+Memed+Abashidze+Ave,+Batumi+6004";
const IG = "https://www.instagram.com/pinch_coffee_ge/";
const TEL = "+995595502265";
const TEL_DISPLAY = "+995 595 50 22 65";

const GALLERY = [
  { src: "/images/interior.jpg", key: "interior" as const, w: "wide" as const },
  { src: "/images/cappuccino.jpg", key: "cappuccino" as const, w: "sq" as const },
  { src: "/images/v60.jpg", key: "v60" as const, w: "sq" as const },
  { src: "/images/cinnamon.jpg", key: "cinnamon" as const, w: "sq" as const },
  { src: "/images/sandwich.jpg", key: "sandwich" as const, w: "sq" as const },
  { src: "/images/beans.jpg", key: "beans" as const, w: "sq" as const },
  { src: "/images/storefront.jpg", key: "storefront" as const, w: "wide" as const },
];

type Tab = "coffee" | "pastries" | "sandwiches";

export function Site() {
  const { lang, theme, setLang, setTheme, hydrate } = usePrefs();
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<Tab>("coffee");
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    date: "",
    time: "",
    guests: "2",
    notes: "",
  });

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const date = tomorrow.toISOString().slice(0, 10);
    setForm((f) => ({
      ...f,
      date: f.date || date,
      time: f.time || "10:00",
    }));
  }, []);

  const tr = (key: CopyKey) => t(lang, key);

  const coffee = useMemo(
    () =>
      [
        ["espresso", "espressoDesc"],
        ["cappuccino", "cappuccinoDesc"],
        ["v60", "v60Desc"],
        ["irish", "irishDesc"],
        ["latte", "latteDesc"],
        ["filter", "filterDesc"],
      ] as const,
    [],
  );
  const pastries = useMemo(
    () =>
      [
        ["cinnamon", "cinnamonDesc", "houseMade"],
        ["seasonal", "seasonalDesc", "daily"],
        ["croissant", "croissantDesc", "daily"],
      ] as const,
    [],
  );
  const sandwiches = useMemo(
    () =>
      [
        ["tuna", "tunaDesc"],
        ["chicken", "chickenDesc"],
        ["tomato", "tomatoDesc"],
      ] as const,
    [],
  );

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim() || !form.date || !form.time) {
      toast.error(tr("required"));
      return;
    }
    saveReservation({
      name: form.name.trim(),
      phone: form.phone.trim(),
      date: form.date,
      time: form.time,
      guests: Number(form.guests) || 2,
      notes: form.notes.trim(),
    });
    setSent(true);
    toast.success(tr("sent"));
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="fixed inset-x-0 top-0 z-40 border-b border-line bg-bg/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <a href="#top" className="font-display text-xl tracking-[0.18em]">
            PINCH
          </a>
          <nav className="hidden items-center gap-7 text-sm text-muted md:flex">
            {(["navAbout", "navMenu", "navGallery", "navVisit"] as const).map((k) => (
              <a
                key={k}
                href={`#${k.replace("nav", "").toLowerCase()}`}
                className="transition-colors duration-150 hover:text-fg"
              >
                {tr(k)}
              </a>
            ))}
            <a
              href="#reserve"
              className="rounded-full border border-line-strong px-4 py-2 text-accent transition-colors duration-150 hover:bg-accent hover:text-accent-fg"
            >
              {tr("navReserve")}
            </a>
          </nav>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setLang(lang === "en" ? "ka" : "en")}
              className="min-h-11 min-w-11 rounded-full border border-line px-3 text-xs tracking-wide text-muted hover:text-fg"
              aria-label="Language"
            >
              {tr("lang")}
            </button>
            <button
              type="button"
              onClick={() => setTheme(theme === "night" ? "day" : "night")}
              className="flex min-h-11 min-w-11 items-center justify-center rounded-full border border-line text-muted hover:text-fg"
              aria-label={theme === "night" ? tr("themeDay") : tr("themeNight")}
            >
              {theme === "night" ? <Sun className="size-4" /> : <Moon className="size-4" />}
            </button>
            <button
              type="button"
              className="flex min-h-11 min-w-11 items-center justify-center rounded-full border border-line md:hidden"
              onClick={() => setOpen((v) => !v)}
              aria-label="Menu"
            >
              {open ? <X className="size-4" /> : <Menu className="size-4" />}
            </button>
          </div>
        </div>
        {open ? (
          <div className="flex flex-col gap-1 border-t border-line px-4 py-3 md:hidden">
            {(
              [
                ["about", "navAbout"],
                ["menu", "navMenu"],
                ["gallery", "navGallery"],
                ["visit", "navVisit"],
                ["reserve", "navReserve"],
              ] as const
            ).map(([id, k]) => (
              <a
                key={id}
                href={`#${id}`}
                onClick={() => setOpen(false)}
                className="rounded-md px-3 py-3 text-sm"
              >
                {tr(k)}
              </a>
            ))}
          </div>
        ) : null}
      </header>

      <section id="top" className="relative flex min-h-dvh items-end overflow-hidden">
        <img
          src="/images/hero.jpg"
          alt=""
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-bg/20" />
        <div className="relative z-10 mx-auto w-full max-w-6xl px-4 pb-20 pt-32 sm:px-6">
          <p className="mb-4 text-xs font-medium uppercase tracking-[0.22em] text-accent">
            {tr("heroEyebrow")}
          </p>
          <h1 className="font-display text-6xl font-medium tracking-[0.08em] sm:text-8xl">
            {tr("heroTitle")}
          </h1>
          <p className="mt-5 max-w-md text-base text-muted">{tr("heroSubtitle")}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#menu"
              className="inline-flex min-h-11 items-center rounded-full bg-accent px-6 text-sm font-medium tracking-wide text-accent-fg transition-transform duration-150 hover:-translate-y-px"
            >
              {tr("heroMenu")}
            </a>
            <a
              href="#visit"
              className="inline-flex min-h-11 items-center rounded-full border border-line-strong px-6 text-sm tracking-wide text-fg transition-colors duration-150 hover:border-accent"
            >
              {tr("heroVisit")}
            </a>
          </div>
        </div>
      </section>

      <section id="about" className="mx-auto grid max-w-6xl gap-12 px-4 py-24 sm:px-6 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-accent">
            {tr("aboutEyebrow")}
          </p>
          <h2 className="mt-3 font-display text-4xl font-medium leading-tight sm:text-5xl">
            {tr("aboutTitle")}
          </h2>
          <p className="mt-6 text-lg text-fg">{tr("aboutLead")}</p>
          <p className="mt-4 text-muted">{tr("aboutBody")}</p>
          <div className="mt-10 grid grid-cols-3 gap-6 border-t border-line pt-8">
            {(
              [
                ["4.6", "statRating"],
                ["241+", "statReviews"],
                ["1st", "statFirst"],
              ] as const
            ).map(([n, k]) => (

              <div key={k}>
                <div className="font-display text-3xl text-accent">{n}</div>
                <div className="mt-1 text-xs uppercase tracking-wider text-subtle">{tr(k)}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-5">
          <img
            src="/images/interior.jpg"
            alt=""
            className="mb-4 aspect-photo w-full rounded-xl object-cover"
          />
          <blockquote className="rounded-xl border border-line bg-surface p-6">
            <p className="text-xs uppercase tracking-[0.16em] text-accent">{tr("quoteLabel")}</p>
            <p className="mt-3 font-display text-xl italic leading-snug">{tr("quoteBody")}</p>
          </blockquote>
        </div>
      </section>

      <section id="menu" className="bg-elevated py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="mx-auto max-w-xl text-center">
            <p className="text-xs font-medium uppercase tracking-[0.2em] text-accent">
              {tr("menuEyebrow")}
            </p>
            <h2 className="mt-3 font-display text-4xl font-medium sm:text-5xl">{tr("menuTitle")}</h2>
            <p className="mt-4 text-muted">{tr("menuDesc")}</p>
          </div>
          <div className="mt-10 flex flex-wrap justify-center gap-2">
            {(["coffee", "pastries", "sandwiches"] as const).map((id) => (
              <button
                key={id}
                type="button"
                onClick={() => setTab(id)}
                className={cn(
                  "min-h-11 rounded-full px-5 text-sm tracking-wide transition-colors duration-150",
                  tab === id
                    ? "bg-accent text-accent-fg"
                    : "border border-line text-muted hover:text-fg",
                )}
              >
                {tr(
                  id === "coffee"
                    ? "tabCoffee"
                    : id === "pastries"
                      ? "tabPastries"
                      : "tabSandwiches",
                )}
              </button>
            ))}
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {tab === "coffee"
              ? coffee.map(([title, desc]) => (
                  <article
                    key={title}
                    className="rounded-xl border border-line bg-surface p-6 transition-transform duration-150 hover:-translate-y-0.5"
                  >
                    <div className="flex items-baseline justify-between gap-3">
                      <h3 className="font-display text-xl">{tr(title)}</h3>
                      <span className="text-xs text-accent">{tr("fromGel")}</span>
                    </div>
                    <p className="mt-3 text-sm text-muted">{tr(desc)}</p>
                  </article>
                ))
              : null}
            {tab === "pastries"
              ? pastries.map(([title, desc, tag]) => (
                  <article
                    key={title}
                    className="rounded-xl border border-line bg-surface p-6"
                  >
                    <div className="flex items-baseline justify-between gap-3">
                      <h3 className="font-display text-xl">{tr(title)}</h3>
                      <span className="text-xs text-accent">{tr(tag)}</span>
                    </div>
                    <p className="mt-3 text-sm text-muted">{tr(desc)}</p>
                  </article>
                ))
              : null}
            {tab === "sandwiches"
              ? sandwiches.map(([title, desc]) => (
                  <article
                    key={title}
                    className="rounded-xl border border-line bg-surface p-6"
                  >
                    <div className="flex items-baseline justify-between gap-3">
                      <h3 className="font-display text-xl">{tr(title)}</h3>
                      <span className="text-xs text-accent">{tr("signature")}</span>
                    </div>
                    <p className="mt-3 text-sm text-muted">{tr(desc)}</p>
                  </article>
                ))
              : null}
          </div>
          {tab === "sandwiches" ? (
            <p className="mt-8 text-center text-sm italic text-subtle">{tr("sandwichNote")}</p>
          ) : null}
        </div>
      </section>

      <section id="gallery" className="mx-auto max-w-6xl px-4 py-24 sm:px-6">
        <p className="text-xs font-medium uppercase tracking-[0.2em] text-accent">
          {tr("galleryEyebrow")}
        </p>
        <h2 className="mt-3 font-display text-4xl font-medium sm:text-5xl">{tr("galleryTitle")}</h2>
        <p className="mt-4 max-w-lg text-muted">{tr("galleryDesc")}</p>
        <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-4">
          {GALLERY.map((item, i) => (
            <button
              key={item.src}
              type="button"
              onClick={() => setLightbox(item.src)}
              className={cn(
                "group overflow-hidden rounded-lg",
                item.w === "wide" ? "col-span-2" : "",
                i === 0 ? "md:col-span-2 md:row-span-2" : "",
              )}
            >
              <img
                src={item.src}
                alt=""
                className="aspect-square size-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </button>
          ))}
        </div>
      </section>

      <section className="border-y border-line bg-elevated py-20">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-4">
          {(
            [
              ["exp1t", "exp1d"],
              ["exp2t", "exp2d"],
              ["exp3t", "exp3d"],
              ["exp4t", "exp4d"],
            ] as const
          ).map(([title, desc]) => (
            <div key={title}>
              <h3 className="font-display text-xl">{tr(title)}</h3>
              <p className="mt-2 text-sm text-muted">{tr(desc)}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="visit" className="mx-auto grid max-w-6xl gap-12 px-4 py-24 sm:px-6 lg:grid-cols-2">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-accent">
            {tr("visitEyebrow")}
          </p>
          <h2 className="mt-3 font-display text-4xl font-medium sm:text-5xl">{tr("visitTitle")}</h2>
          <dl className="mt-10 grid gap-8 sm:grid-cols-2">
            <div>
              <dt className="text-xs uppercase tracking-wider text-accent">{tr("address")}</dt>
              <dd className="mt-2 text-muted">
                60 Memed Abashidze Ave
                <br />
                Batumi 6004
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wider text-accent">{tr("hours")}</dt>
              <dd className="mt-2 text-muted">
                {tr("hoursWeek")}
                <br />
                {tr("hoursWeekend")}
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wider text-accent">{tr("phone")}</dt>
              <dd className="mt-2">
                <a className="text-muted hover:text-accent" href={`tel:${TEL}`}>
                  {TEL_DISPLAY}
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wider text-accent">{tr("services")}</dt>
              <dd className="mt-2 text-muted">{tr("dineTake")}</dd>
            </div>
          </dl>
          <a
            href={MAPS}
            target="_blank"
            rel="noreferrer"
            className="mt-8 inline-flex min-h-11 items-center gap-2 rounded-full bg-accent px-6 text-sm font-medium text-accent-fg"
          >
            <MapPin className="size-4" />
            {tr("openMaps")}
          </a>
        </div>
        <div className="relative overflow-hidden rounded-xl">
          <img src="/images/storefront.jpg" alt="" className="size-full min-h-72 object-cover" />
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg to-transparent p-6">
            <p className="flex items-center gap-2 text-sm text-fg">
              <Clock className="size-4 text-accent" />
              {tr("nearMuseum")}
            </p>
          </div>
        </div>
      </section>

      <section id="reserve" className="bg-elevated py-24">
        <div className="mx-auto grid max-w-6xl gap-12 px-4 sm:px-6 lg:grid-cols-2">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.2em] text-accent">
              {tr("reserveEyebrow")}
            </p>
            <h2 className="mt-3 font-display text-4xl font-medium sm:text-5xl">
              {tr("reserveTitle")}
            </h2>
            <p className="mt-4 text-muted">{tr("reserveDesc")}</p>
          </div>
          {sent ? (
            <div className="rounded-xl border border-line bg-surface p-8">
              <h3 className="font-display text-2xl">{tr("sent")}</h3>
              <p className="mt-3 text-muted">{tr("sentBody")}</p>
              <a
                href={`tel:${TEL}`}
                className="mt-6 inline-flex min-h-11 items-center gap-2 text-accent"
              >
                <Phone className="size-4" />
                {TEL_DISPLAY}
              </a>
            </div>
          ) : (
            <form onSubmit={submit} className="rounded-xl border border-line bg-surface p-6 sm:p-8">
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block text-sm">
                  <span className="text-subtle">{tr("name")}</span>
                  <input
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg outline-none focus:border-accent"
                  />
                </label>
                <label className="block text-sm">
                  <span className="text-subtle">{tr("phone")}</span>
                  <input
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    className="mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg outline-none focus:border-accent"
                  />
                </label>
                <label className="block text-sm">
                  <span className="text-subtle">{tr("date")}</span>
                  <input
                    type="date"
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    className="mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg outline-none focus:border-accent"
                  />
                </label>
                <label className="block text-sm">
                  <span className="text-subtle">{tr("time")}</span>
                  <input
                    type="time"
                    value={form.time}
                    onChange={(e) => setForm({ ...form, time: e.target.value })}
                    className="mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg outline-none focus:border-accent"
                  />
                </label>
                <label className="block text-sm">
                  <span className="text-subtle">{tr("guests")}</span>
                  <select
                    value={form.guests}
                    onChange={(e) => setForm({ ...form, guests: e.target.value })}
                    className="mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg outline-none focus:border-accent"
                  >
                    {[1, 2, 3, 4, 5, 6].map((n) => (
                      <option key={n} value={n}>
                        {n}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block text-sm sm:col-span-2">
                  <span className="text-subtle">{tr("notes")}</span>
                  <textarea
                    value={form.notes}
                    placeholder={tr("notesPh")}
                    onChange={(e) => setForm({ ...form, notes: e.target.value })}
                    rows={3}
                    className="mt-1 w-full rounded-md border border-line bg-bg px-3 py-2 text-fg outline-none focus:border-accent"
                  />
                </label>
              </div>
              <button
                type="submit"
                className="mt-6 inline-flex min-h-11 w-full items-center justify-center rounded-full bg-accent px-6 text-sm font-medium text-accent-fg sm:w-auto"
              >
                {tr("send")}
              </button>
            </form>
          )}
        </div>
      </section>

      <section className="mx-auto max-w-2xl px-4 py-24 text-center sm:px-6">
        <h2 className="font-display text-4xl font-medium whitespace-pre-line sm:text-5xl">
          {tr("contactTitle")}
        </h2>
        <p className="mt-4 text-muted">{tr("contactBody")}</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <a
            href={IG}
            target="_blank"
            rel="noreferrer"
            className="inline-flex min-h-11 items-center rounded-full border border-line-strong px-5 text-sm text-muted hover:text-fg"
          >
            {tr("instagram")}
          </a>
          <a
            href={`tel:${TEL}`}
            className="inline-flex min-h-11 items-center rounded-full border border-line-strong px-5 text-sm text-muted hover:text-fg"
          >
            {tr("callUs")}
          </a>
          <a
            href={MAPS}
            target="_blank"
            rel="noreferrer"
            className="inline-flex min-h-11 items-center rounded-full border border-line-strong px-5 text-sm text-muted hover:text-fg"
          >
            {tr("maps")}
          </a>
        </div>
      </section>

      <footer className="border-t border-line py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 px-4 sm:flex-row sm:items-center sm:px-6">
          <div>
            <div className="font-display text-lg tracking-[0.16em]">PINCH</div>
            <p className="text-sm text-subtle">{tr("footerTag")}</p>
          </div>
          <p className="text-sm text-subtle">60 Memed Abashidze Ave, Batumi</p>
        </div>
      </footer>

      {lightbox ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-bg/90 p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            type="button"
            className="absolute top-4 right-4 flex min-h-11 min-w-11 items-center justify-center rounded-full border border-line"
            aria-label={tr("close")}
            onClick={() => setLightbox(null)}
          >
            <X className="size-4" />
          </button>
          <img
            src={lightbox}
            alt=""
            className="max-h-[85vh] max-w-full rounded-lg object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      ) : null}
    </div>
  );
}
